using ColdvisioApi.Application.IService;

namespace ColdvisioApi.Application.Service
{
    public class HelloWorldService : IHelloWorldService
    {
        public string GetMessage()
        {
            return "Olá, mundo! Serviço Coldvisio ativo.";
        }
    }
}
