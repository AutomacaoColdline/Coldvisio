using Microsoft.Extensions.DependencyInjection;
using ColdvisioApi.Application.IService;
using ColdvisioApi.Application.Service;

namespace ColdvisioApi.Application.Configurations
{
    public static class ServiceRegistration
    {
        public static void ConfigureServices(IServiceCollection services)
        {
            services.AddScoped<IHelloWorldService, HelloWorldService>();
        }
    }
}
