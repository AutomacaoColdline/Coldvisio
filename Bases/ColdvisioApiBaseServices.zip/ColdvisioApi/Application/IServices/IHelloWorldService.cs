namespace ColdvisioApi.Application.IService
{
    public interface IHelloWorldService
    {
        string GetMessage();
    }
}
